package z2;

public class Main {
    public static void main(String[] args) {
        Drukarka drukarka = new Drukarka();
        drukarka.start("src/z2/dane.txt", "src/z2/wynik.txt");
    }
}
