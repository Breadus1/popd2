package z1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Kalkulator kalkulator = new Kalkulator();
        kalkulator.oblicz("src/z1/dane1.txt", "src/z1/wynik.txt");
    }

    static class Kalkulator {
        public void oblicz(String inputFile, String outputFile) {
            File file = new File(inputFile);
            PrintWriter writer = null;

            try {
                Scanner scanner = new Scanner(file);
                writer = new PrintWriter(outputFile);

                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    String[] parts = line.split(" ");
                    
                    int liczba1 = Integer.parseInt(parts[0]);
                    char dzialanie = parts[1].charAt(0);
                    int liczba2 = Integer.parseInt(parts[2]);
                    int wynik;

                    try {
                        switch (dzialanie) {
                            case '+':
                                wynik = liczba1 + liczba2;
                                break;
                            case '-':
                                wynik = liczba1 - liczba2;
                                break;
                            case '*':
                                wynik = liczba1 * liczba2;
                                break;
                            case '/':
                                if (liczba2 == 0) {
                                    throw new ArithmeticException("Dzielenie przez zero");
                                }
                                wynik = liczba1 / liczba2;
                                break;
                            default:
                                continue;
                        }

                        writer.println(wynik);
                    } catch (ArithmeticException e) {
                        writer.println(e.getMessage());
                    }
                }
            } catch (FileNotFoundException e) {
                System.err.println("Nie znaleziono pliku");
                return;
            } finally {
                if (writer != null) {
                    writer.close();
                }
            }
        }
    }
}
